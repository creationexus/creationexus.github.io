package chatnoapplet.tcp.cliente;

/**
 *
 * @author carriagadad
 */
public class HiloUsuariosOnline {
    
}
