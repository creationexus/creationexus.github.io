package chatnoapplet.graficos;

/**
 *
 * @author carriagadad
 */
public interface InterfazGrafica {
    public void entrada(String s);
}
